def Articles():
    articles = [
        {
        
        # data data data
        # tables?

        }
    ]

    return articles