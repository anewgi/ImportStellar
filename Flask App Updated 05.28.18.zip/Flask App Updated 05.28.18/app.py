import os
import json

import datetime as dt
import numpy as np
import pandas as pd

from flask import (
    Flask,
    render_template,
    jsonify,
    request)
import sqlalchemy

from sqlalchemy import create_engine, inspect, func
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base


# from data import Articles

app = Flask(__name__)

# Articles = Articles()

# app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', '') or "mysql:///P2_attempt_two.sqlite"

engine = create_engine('sqlite:///P2_attempt_two.sqlite', echo=True)
# reflect an existing database into a new model
Base = automap_base()
# reflect the tables
Base.prepare(engine, reflect=True)

# Save references to each table == name each
Temperature = Base.classes.temperature_dataset
Carbon_dioxide = Base.classes.co2_dataset

# Create our session (link) from Python to the DB
session = Session(engine)


@app.route("/")
def home():
    return render_template("index.html")

# class Year(db.Model):
#   __tablename__ = ‘example’
#   id = db.Column(‘id’, db.Integer, primary_key=True)
#   year = db.Column(‘year’)

@app.route("/CO2")
def C02():
    return render_template("CO2.HTML")

@app.route("/test")
def test():
    return render_template("test.HTML")

@app.route("/heatmap")
def heatmap():
    return render_template("heatmap.HTML")



# test!
# @app.route("/articles")
# def articles():
#     return render_template("articles.HTML", articles = Articles)



    
if __name__ == "__main__":
    app.run(debug=True)

    ## return fucntion api we did this in class, several times